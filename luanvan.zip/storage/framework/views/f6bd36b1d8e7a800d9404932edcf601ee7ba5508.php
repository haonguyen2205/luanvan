<!-- Header Section Begin -->
<header class="header-section">
        <div class="container-fluid">
            <div class="inner-header">
                <div class="logo">
                    <a href="<?php echo e(URL::to('/')); ?>"><img src="<?php echo e(URL::asset('public/frontend/img/logo.png')); ?>" alt=""></a>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-xl-8">
                            <nav class="main-menu mobile-menu">
                                <ul>
                                        <li><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
                                        <li><a href="<?php echo e(URL::to('/about-us')); ?>">About</a></li>
                                        <li><a href="<?php echo e(URL::to('/rooms')); ?>">Rooms</a></li>
                                        <li><a href="<?php echo e(URL::to('/news')); ?>">News</a></li>
                                        <li><a href="<?php echo e(URL::to('/contact')); ?>">Contact</a></li>
                                </ul>
                            </nav>



                        </div>
                        <div class="col-xl-4">
                            <nav  class="main-menu mobile-menu">
                                <ul>
                                    <?php if(Session::has('name') && Session::get('role')==0): ?>
                                    <li><a href="<?php echo e(URL::to('/profile')); ?>">
                                            <?php
                                            $name =Session::Get('name');
                                            if($name)
                                                echo $name;

                                            ?>
                                        </a></li>
                                        <li><a href="<?php echo e(URL::to('/logout')); ?>">Logout</a></li>
                                    <?php else: ?>
                                       <li><a href="<?php echo e(URL::to('/login')); ?>">Login</a></li>
                                        <li><a href="<?php echo e(URL::to('/showregister')); ?>">Register</a></li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                <div id="mobile-menu-wrap"></div>
            </div>
        </div>
    </header>
    
    <!-- Header End -->
<?php /**PATH C:\wamp64\www\luanvan\resources\views/header.blade.php ENDPATH**/ ?>