

<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
    
    <div class="panel panel-default">
      <div class="panel-heading">
        Danh sách loại phòng không hoạt động
      </div>
      <ul class="nav nav-tabs">
        <li><a href="<?php echo e(URL::to('/list-type')); ?>"> <span class="glyphicon glyphicon-bed"></span> DS loại phòng </a></li>
        <li><a href="<?php echo e(URL::to('/list-type-block')); ?>" ><span class="glyphicon glyphicon-bed"></span> DS khóa</a></li>
    </ul>
      <div class="row w3-res-tb">
        <div class="col-sm-5 m-b-xs">
          <a href="<?php echo e(URL::to('/add-type')); ?>" class="btn btn-info">thêm loại phòng</a>              
        </div>
        <div class="col-sm-4">
          
        </div>
        <div class="col-sm-3">
          <div class="input-group">
            <form>
              <input type="text" class="input-sm form-control" name="search_type" placeholder="Search">
              <span class="input-group-btn">
                <button class="btn btn-sm btn-default" name="btn_type" type="button">Search!</button>
              </span>
            </form>
          </div>
          
        </div>
      </div>

      <!-- // show dữ liệu -->
      <div class="table-responsive">
        <table class="table table-striped b-t b-light">
          <thead>
            <tr>
              <th style="width:20px;"></th>
              <th>mã loại</th>
              <th>Tên loại</th>
              <th>Trạng thái</th>
              <th>Display</th>
              <th style="width:30px;"></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $listType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
              <td><label class="i-checks m-b-none"><i></i></label></td>
                <td> <?php echo e($type->type_id); ?> </td>
                <td> <?php echo e($type->type_name); ?> </td>

                <td><span class="text-ellipsis">
                    <?php
                      if($type->status==0) {
                    ?>
                      <a href="<?php echo e(URL::to('/inactive-type/'.$type->type_id)); ?>" style="color:red">Không hoạt động</a>
                    <?php
                      }
                      else {
                    ?>
                      <a href="<?php echo e(URL::to('/active-type/'.$type->type_id)); ?>" style="color:green">Đang hoạt động</a>
                    <?php
                      }
                    ?>
                  </span>
                </td>
                <td>
                  <a href="<?php echo e(URL::to('/edit-type/'.$type->type_id)); ?>" class="active" style="font-size: 21px;" ui-toggle-class="">
                    <i class="fa fa-pencil-square-o text-success text-active"></i>
                  </a>
                  <a href="<?php echo e(URL::to('/delete-type/'.$type->type_id)); ?>" onClick="return confirm('Bạn thực sự muốn xóa ?')"class="active" style="font-size: 21px;"  ui-toggle-class="">
                    <i class="fa fa-times text-danger text"></i>
                  </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    <!-- end show dữ liệu -->

      <footer class="panel-footer">
        <div class="row">
          <div class="col-sm-7 text-right text-center-xs">                
          <?php echo e($listType->links()); ?>

          </div>
        </div>
      </footer>

    </div>
</div>



<?php if(Session::has('mes_create')): ?>
  <script type="text/javascript" >
    swal("Congratulation!","<?php echo e(Session::Get('mes_create')); ?>","success",{
      button:"OK",
    });
  </script> 
  <?php
    session::put('mes_create',null);
  ?>
<?php endif; ?>

<?php if(Session::has('mes_delete')): ?>
  <script type="text/javascript" >
    swal("thông báo","<?php echo e(Session::Get('mes_delete')); ?>","warning",{
      button:"OK",
    });
  </script> 
  <?php
    session::put('mes_delete',null);
  ?>
<?php endif; ?>

<?php if(Session::has('mes_update')): ?>
  <script type="text/javascript" >
    swal("Báo cáo đọi trưởng!","<?php echo e(Session::Get('mes_update')); ?>","success",{
      button:"OK",
    });
  </script> 
  <?php
    session::put('mes_update',null);
  ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/Admin/typeroom/list_block.blade.php ENDPATH**/ ?>