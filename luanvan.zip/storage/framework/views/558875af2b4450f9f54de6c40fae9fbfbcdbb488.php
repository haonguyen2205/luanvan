
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                THÊM LOẠI PHÒNG
            </header>
            <div class=" panel-body">
                    <!-- form nhập dữ liệu loại phòng  -->
                <div class="position-center">
                    <form role="form" action="<?php echo e(URL::to('/add-type-action')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label >Tên loại</label>
                            <input type="text" class="form-control my-2" id="exampleInputEmail1" min="3" max="50" name="typeName">
                        </div><span style="color: red;"><?php echo e($errors->first('typeName')); ?></span>

                        <div class="form-group">
                            <label >số lượng phòng dự kiến</label>
                            <input type="number" class="form-control my-2" id="exampleInputEmail1" min="1" max="5" name="quality">
                        </div><span style="color: red;"><?php echo e($errors->first('quality')); ?></span>

                        <div class="form-group">
                            <label for="exampleInputEmail1">số người tối đa</label>
                            <input type="number" class="form-control my-2" id="exampleInputEmail1" min="1" max="5" name="capacity">
                        </div><span style="color: red;"><?php echo e($errors->first('capacity')); ?></span>

                        
                        <div class="form-group">
                            <label for="exampleInputFile">Trạng thái</label>
                            <select name="typeStatus" class="form-control my-2 m-bot15">
                                <option value="1">Hoạt động</option>
                                <option value="0">Không hoạt động</option>
                            </select>
                        </div>
                        <div class="form-group my-2">
                            <label for="exampleInputEmail1">tiện ích :  </label></br>
                            <label for="exampleInputEmail1"></label></br>
                            <?php $__currentLoopData = $utility; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $uti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <input type="checkbox"  value="<?php echo e($uti->utility_id); ?>"  name="tienich[]">
                                <?php echo e($uti->utility_name); ?> 
                                <img src="<?php echo e(URL::to('/public/upload/utility/'.$uti->utility_image)); ?>" weight="30" height="30" width="35"/> &nbsp;|&nbsp;
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <span style="color: red;"><?php echo e($errors->first('typeName')); ?></span>
                        <button type="submit" class="btn btn-info" name="addType">Submit</button>
                    </form>

                    <ul class=" alert text-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    
                        <li><?php echo e($error); ?></li>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                
                    <!--End form nhập dữ liệu loại phòng  -->
            </div>
        </section>

    </div>
</div>
      
            <div class="my-5">
                <div class="container">
                    <div class="row">
                        <div class="owl-carousel owl-theme ">
                            <?php $__currentLoopData = $img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item">
                                    <div> </div>
                                    <div class="col mt-5 mb-5">
                                        <div class="cart">
                                            
                                            <img src="<?php echo e(asset('public/upload/rooms/'.$imgroom->room_image)); ?>" width="350" height="200">
                                            
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>  

<?php if(Session::has('mes_tienich')): ?>
  <script type="text/javascript" >
    swal("FAILS!","<?php echo e(Session::Get('mes_tienich')); ?>","warning",{
      button:"OK",
    });
  </script> 
  <?php
    session::put('mes_tienich',null);
  ?>
<?php endif; ?>


<Script>
    $(document).ready(function () {
        (function ($) {
            $('.owl-carousel').owlCarousel({
                margin: 10,
                // slideSpeed : 800,
                // autoPlay: 2000,
                items : 3,
                autoplay:true,
                autoplayTimeout:2000,
                loop: true,
                stopOnHover : true,
                itemsDesktop : [1199,1],
                itemsDesktopSmall : [979,1],
                itemsTablet :   [768,1],
            });
        })(jQuery);
    });
</Script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/admin/typeroom/add.blade.php ENDPATH**/ ?>