
<?php $__env->startSection('admin_content'); ?>
<div class="table-agile-info">
    
    <div class="panel panel-default">
      <div class="panel-heading">
        <Div>Danh sách phòng</Div>
    </div>
          <ul class="nav nav-tabs">
              <li><a href="<?php echo e(URL::to('/list-room')); ?>" > <span class="glyphicon glyphicon-bed"></span> DS phòng </a></li>
              <li><a href="<?php echo e(URL::to('/list-room-block')); ?>" ><span class="glyphicon glyphicon-bed"></span> DS phòng KO HĐ</a></li>
              <li><a href="<?php echo e(URL::to('/list-empty-room')); ?>" ><span class="glyphicon glyphicon-bed"></span> tìm phòng rỗng</a></li>
          </ul>
        <div class="row w3-res-tb">
          <form class="form-group" action="<?php echo e(URL::To('/check-avalibility')); ?>" method="get">
          <?php echo e(csrf_field()); ?>

              <div class="row">

                <div class="col-md-1"></div>
                <div class="col-md-3">
                    <div class="form-group">
                        <input class="form-control date" type="date" name="start_time" id="start_time" value="<?php echo e(request()->input('start_time')); ?>" placeholder="<?php echo e(trans('cruds.event.fields.start_time')); ?>" required>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <input class="form-control date" type="date" name="end_time" id="end_time" value="<?php echo e(request()->input('end_time')); ?>" placeholder="<?php echo e(trans('cruds.event.fields.end_time')); ?>" required>
                    </div>
                </div>
               
                <div class="col-md-2">
                    <button class="btn btn-success">
                        tìm kiếm
                    </button>
                </div>
            </div>  
          </form>
      
        </div>

</div>

<?php if(Session::has('mes_saingay')): ?>
    <script type="text/javascript" >
      swal("Thông b!","<?php echo e(Session::Get('mes_saingay')); ?>","error",{
        button:"OK",
      });
      <?php
      session::put('mes_saingay',null);
    ?>
    </script> 
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/Admin/room/check_availability.blade.php ENDPATH**/ ?>