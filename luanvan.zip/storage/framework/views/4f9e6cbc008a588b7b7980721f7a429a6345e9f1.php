
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Form thêm tiện ích
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <?php $__currentLoopData = $editsv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form role="form" action="<?php echo e(URL::to('/update-service/'.$ser->service_id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Tên dịch vụ 1 </label>      
                            <input type="text" class="form-control" value="<?php echo e($ser->service_name); ?>"  min="3" max="50" name="sv_name1" required>
                            <span style="color: red;"><?php echo e($errors->first('uti_name')); ?></span>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Tên dịch vụ 2</label>      
                            <input type="text" class="form-control" value="<?php echo e($ser->name); ?>" min="3" max="50" name="sv_name2" required>
                            <span style="color: red;"><?php echo e($errors->first('uti_name')); ?></span>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">giá tiền</label>
                            
                            <input type="number" class="form-control" value="<?php echo e($ser->service_price); ?>" min="10000" maxlength="10"  name="sv_price" required>
                            <span style="color: red;"></span>
                        </div>
                        </br>

                        <button type="submit" class="btn btn-info" name="addType">Submit</button>
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/admin/service/edit.blade.php ENDPATH**/ ?>