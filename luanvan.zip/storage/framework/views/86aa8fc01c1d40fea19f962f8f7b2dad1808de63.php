
<?php $__env->startSection('admin_content'); ?>
<div class="table-align-info">
    <div class="panel panel-default">
        <div class="panel-heading"> DANH SÁCH ĐƠN HÀNG </div>
        <div class="row w3-res-tb">
            <div class="col-sm-4"></div>
            <div class="col-sm-4">
                <div class="input-group">
                    <form action="<?php echo e(URL::to('timkiem')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                    
                         <select name="trangthai">
                                <option value="-2"<?php if($sttse == -2)echo "selected"; ?> >Trạng thái </option>
                                <option value="0" <?php if($sttse == 0)echo "selected"; ?>>Đã huỷ</option>
                                <option value="1" <?php if($sttse == 1)echo "selected"; ?>>Đang chờ</option>
                                <option value="2" <?php if($sttse == 2)echo "selected"; ?>>Đã xác nhận</option>
                                <option value="3" <?php if($sttse == 3)echo "selected"; ?>>Đã lấy phòng</option>
                                <option value="4" <?php if($sttse == 4)echo "selected"; ?>>Hoàn thành</option>
                                </select>
                        <div class="btn">

                            <input type="text" class="input-sm form-control" name="search" placeholder="Nhập tên khách hàng">
                            <button type="submit"  class="btn btn-primary" value="Tìm kiếm"><i class="fas fa-search"></i> TÌM KIẾM</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-sm-4"></div>
        </div>

        <div class="table-responsive">
            <table class="table table-striped b-t b-light">
                <thead>
                    <tr>
                        <th style="width:20px;">ID</th>
                        <th>Tên người đặt</th>
                        <th>CMND</th>
                        <th> Phòng </th>
                        <th>Tổng tiền</th>
                        <th>Ngày nhận</th>
                        <th>Ngày trả</th>
                        <th>Tình trạng</th>
                        <th>Tiền cọc</th>
                        <th>Xóa</th>
                        <th style="width:30px;">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><label class="i-checks m-b-none"><i><?php echo e($key['id']); ?></i></label></td>
                        <td> <?php echo e($key['name']); ?> </td>
                        <td> <?php echo e($key['cmnd']); ?> </td>
                        <td> <?php echo e($key['phong']); ?> </td>

                        <td><span class="text-ellipsis"><?php echo e(number_format($key['tongtien'],0)); ?>VND</span></td>
                        <td><span class="text-ellipsis"><?php echo e($key['ngaynhan']); ?></span></td>
                        <td><span class="text-ellipsis"><?php echo e($key['ngaytra']); ?></span></td>
                        <td><span class="text-ellipsis">
                        <?php if($key['tinhtrang']==0): ?>
                            <p style="color:rose">Đã huỷ</p>
                            <?php endif; ?>
                        <?php if($key['tinhtrang']==1): ?>
                            <a style="color:red" href="<?php echo e(URL::to('uptt',$key['id'])); ?>">Chờ xác nhận</a>
                            <?php endif; ?>
                                <?php if($key['tinhtrang']==2): ?>
                                <a style="color:black" href="<?php echo e(URL::to('uptt',$key['id'])); ?>">Đã xác nhận</a>;
                            <?php endif; ?>
                                <?php if($key['tinhtrang']==3): ?>
                                <a style="color:green" href="<?php echo e(URL::to('uptt',$key['id'])); ?>">Đã lấy phòng</a>;
                            <?php endif; ?>
                                <?php if($key['tinhtrang']==4): ?>
                                <p style="color:blue">Hoàn thành</p>
                        <?php endif; ?>
                        </span></td>
                        <td><?php echo e(number_format($key['deposit'],0)); ?> VND</td>
                        <td>
                            <?php if($key['tinhtrang']==0): ?>
                        <a href="<?php echo e(URL::to('xoa',$key['id'])); ?>" class="btn btn-danger" style="font-size: 13px"  ui-toggle-class="">
                        <i class="fas fa-trash-alt"></i> Xóa
                        </a>
                        <?php endif; ?>
                        </td>
                        <td>
                        <a href="<?php echo e(URL::to('/admin/chitietorder',$key['id'])); ?>" class="btn btn-primary" style="font-size: 13px"  ui-toggle-class="">
                        <i class="icon icon-edit"></i> Chi tiết
                        </a>
                        <?php if($key['tinhtrang']==1 || $key['tinhtrang']==2): ?>
                        <a href="<?php echo e(URL::to('/admin/huy',$key['id'])); ?>" class="btn btn-danger" style="font-size: 13px"  ui-toggle-class="">
                        Hủy
                        </a>
                        <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/Admin/order/list.blade.php ENDPATH**/ ?>