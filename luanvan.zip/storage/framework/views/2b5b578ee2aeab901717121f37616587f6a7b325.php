


<?php $__env->startSection('admin_content'); ?>
<div class="table-agile-info">
    
    <div class="panel panel-default">
      <div class="panel-heading">
        <Div>Danh sách phòng</Div>
    </div>
          <<ul class="nav nav-tabs">
              <li><a href="<?php echo e(URL::to('/list-room')); ?>" > <span class="glyphicon glyphicon-bed"></span> DS phòng </a></li>
              <li><a href="<?php echo e(URL::to('/list-room-block')); ?>" ><span class="glyphicon glyphicon-bed"></span> DS phòng KO HĐ</a></li>
              <li><a href="<?php echo e(URL::to('/list-empty-room')); ?>" ><span class="glyphicon glyphicon-bed"></span> tìm phòng rỗng</a></li>
              <li><a href="<?php echo e(URL::to('/list-of-occupied')); ?>" ><span class="glyphicon glyphicon-bed"></span> DS phòng có ngưởi ở</a></li>
          </ul>
        <div class="row w3-res-tb">
          <form class="form-group" action="<?php echo e(URL::To('/check-avalibility')); ?>" method="get">
          <?php echo e(csrf_field()); ?>

              <div class="row">

                <div class="col-md-1"></div>
                <div class="col-md-3">
                    <div class="form-group">
                        <input class="form-control date" type="date" name="start_time" id="start_time" value="<?php echo e(request()->input('start_time')); ?>" placeholder="<?php echo e(trans('cruds.event.fields.start_time')); ?>" required>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <input class="form-control date" type="date" name="end_time" id="end_time" value="<?php echo e(request()->input('end_time')); ?>" placeholder="<?php echo e(trans('cruds.event.fields.end_time')); ?>" required>
                    </div>
                </div>
                <!-- <div class="col-md-3">
                    <div class="form-group">
                        <input class="form-control" type="number" name="capacity" id="capacity" value="<?php echo e(request()->input('capacity')); ?>" placeholder="<?php echo e(trans('cruds.room.fields.capacity')); ?>" step="1" required>
                    </div>
                </div> -->
                <div class="col-md-2">
                    <button class="btn btn-success">
                        tìm kiếm
                    </button>
                </div>
            </div>  
          </form>
      
        </div>

        <?php if($room!==null): ?> 
            

          <hr />
          <div class="table-responsive">
              <table class=" table table-bordered table-striped table-hover datatable datatable-Event">
                  <thead>
                      <tr>
                          <th>
                              tên phòng 
                          </th>
                          <th>
                              ảnh
                          </th>
                          <th>
                            loại phòng
                          </th>
                          <th>
                              giá
                          </th>
                          <th>
                              Action&nbsp;
                          </th>
                      </tr>
                  </thead>
                  <tbody>
                        <input type="hidden" name="start_time" value="<?php echo e($star); ?>">
                        <input type="hidden" name="end_time" value="<?php echo e($end); ?>">
                      <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                            <tr>
                                <td class="room-name">
                                    <?php echo e($r->room_name); ?>

                                </td>
                                <td class="room-name">
                                    <div class="single-room-pic">
                                    <img src="public/upload/rooms/<?php echo e($r->image); ?>" height="150"; width="350";>
                                    </div>
                                </td>
                                <td>
                                    <?php echo e($r->type_id); ?>

                                </td>
                                <td>
                                    <?php echo e(number_format($r->room_price)); ?> đ/ngày
                                </td>
                                <td>
                                    
                                    <a href="<?php echo e(URL::to('/order_room/'.$r->room_id)); ?>" data-room-id="<?php echo e($r->room_id); ?>" class="btn btn-primary">
                                    
                                    Đặt phòng</a>
                                </td>

                            </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
              </table>
          </div>

        <?php else: ?> <p class="text-center">There are no rooms available at the time you have chosen</p>
        <?php endif; ?>
</div>

<!-- <div class="modal" tabindex="-1" role="dialog" id="bookRoom">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Booking of a room</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('bookRoom')); ?>" method="POST" id="bookingForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="room_id" id="room_id" value="<?php echo e(old('room_id')); ?>">
                    <input type="hidden" name="start_time" value="<?php echo e(request()->input('start_time')); ?>">
                    <input type="hidden" name="end_time" value="<?php echo e(request()->input('end_time')); ?>">
                    <div class="form-group">
                    <label for="description">người đặt</label>
                        <input class="form-control" type="text" name="title" id="title" value="<?php echo e(Session::get('name')); ?>" required>
                        <?php if($errors->has('title')): ?>
                            <div class="invalid-feedback">
                                <?php echo e($errors->first('title')); ?>

                            </div>
                        <?php endif; ?>
                       
                    </div>
                    <div class="form-group">
                        <label for="description"></label>
                        <input type="text" id="description" name="adults">
                        <input type="text" id="description" name="children">
                    </div>
                    <div class="form-group">
                        <label for="recurring_until"></label>
                        
                    </div>
                    <button type="submit" style="display: none;"></button>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="submitBooking">Submit</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div> -->
 

<?php $__env->stopSection(); ?>
<!-- <?php $__env->startSection('scripts'); ?>
<script>
$('#bookRoom').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget);
    var roomId = button.data('room_id');
    var modal = $(this);
    modal.find('#room_id').val(roomId);
    modal.find('.modal-title').text('Booking of a room ' + button.parents('tr').children('.room-name').text());

    $('#submitBooking').click(() => {
        modal.find('button[type="submit"]').trigger('click');
    });
});
</script>
<?php $__env->stopSection(); ?> -->
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views//Admin/room/list_empty.blade.php ENDPATH**/ ?>