
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Cập nhật loại sản phẩm 
            </header>
            <div class="panel-body">
                <?php
                    $msg = Session::get('msg');
                    if($msg) {
                        echo "<b style='color:red; padding-left:500px;'>".$msg."</b>";
                        Session::put('msg',null);
                    }
                ?>
                <?php $__currentLoopData = $edittype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="position-center">
                    <form role="form" action="<?php echo e(URL::to('/update-type/'.$edit_type->type_id)); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Mã loại phòng</label>
                            <input type="text" value="<?php echo e($edit_type->type_id); ?>" readonly disabled class="form-control my-2"  name="typeName">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Tên loại</label>
                            <input type="text" value="<?php echo e($edit_type->type_name); ?>" required class="form-control my-2" name="typeName">
                        </div>
                        <span style="color: red;"><?php echo e($errors->first('typeName')); ?></span>

                        <div class="form-group">
                            <label for="exampleInputEmail1">số lượng phòng </label>
                            <input type="number" class="form-control my-2" value="<?php echo e($edit_type->quality); ?>" min="1" max="12" name="quality">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">số người tối đa </label>
                            <input type="number" class="form-control my-2" value="<?php echo e($edit_type->capacity); ?>" min="1" max="6" name="capacity">
                        </div>

                        <button type="submit" class="btn btn-info" name="updateType">Cập nhật</button>
                    </form>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/admin/typeroom/edit.blade.php ENDPATH**/ ?>