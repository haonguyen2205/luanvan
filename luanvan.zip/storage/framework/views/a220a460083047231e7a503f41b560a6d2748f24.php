
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                chỉnh sửa tên tiện ích 
            </header>
            <div class="panel-body">
                <?php $__currentLoopData = $edit_uti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $uti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="position-center">
                        <form role="form" action="<?php echo e(URL::to('/update-uti/'.$uti->utility_id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Mã Tiện ích</label>
                                <input type="text" value="<?php echo e($uti->utility_id); ?>" readonly class="form-control" id="exampleInputEmail1" name="uti_id">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Tên loại</label>
                                <input type="text" value="<?php echo e($uti->utility_name); ?>" class="form-control" id="exampleInputEmail1" name="uti_name">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">giá tiện ích</label>
                                <input type="number" value="<?php echo e($uti->utility_price); ?>" min="10000" max="30000000" class="form-control" id="exampleInputEmail1" name="uti_price">
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">ảnh tiện ích</label>
                                <input type="file" value="" class="form-control" accept="image/*"  name="uti_image">
                                <img src="<?php echo e(URL::to('/public/upload/utility/'.$uti->utility_image)); ?>" height="100" weight="100"/>
                            </div>

                            <button type="submit" class="btn btn-info" name="updateType">submit</button>
                        </form>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

    </div>
</div>

<?php if(Session::has('mes_fails')): ?>
  <script type="text/javascript" >
    swal("thành công!","<?php echo e(Session::Get('mes_update')); ?>","error",{
      button:"OK",
    });
  </script> 
  <?php
    session::put('mes_fails',null);
  ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/Admin/utility/edit.blade.php ENDPATH**/ ?>