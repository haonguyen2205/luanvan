
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                    CẬP NHẬT THÔNG TIN NHÂN VIÊN
            </header>
            <div class="panel-body">

                <!-- nhập thong tin chinh sua -->
                <div class="position-center">
                    <?php $__currentLoopData = $editStaff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $edit_staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form role="form" action="<?php echo e(URL::to('/update_staff/'.$edit_staff->users_id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Họ Tên</label>
                                <input type="text" class="form-control" value="<?php echo e($edit_staff->name); ?>" min="3" max="50" name="name" required>
                            </div>
                            <span style="color: red;"><?php echo e($errors->first('name')); ?></span>

                            <div class="form-group">
                                <label for="exampleInputEmail1">ảnh cá nhân </label>
                                <input type="file" class="form-control" accept="image/*" min="3" max="50" name="image">
                                <img src="<?php echo e(URL::to('/public/upload/staff/'.$edit_staff->users_image)); ?>" height="100" weight="100"/>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">số điện thoại</label>
                                <input type="text" class="form-control" value="<?php echo e($edit_staff->phone); ?>" min="3" max="50" name="phone" required="">
                            </div>
                            <span style="color: red;"><?php echo e($errors->first('phone')); ?></span>

                            <div class="form-group">
                                <label for="exampleInputEmail1">địa chỉ </label>
                                <input type="text" class="form-control" value="<?php echo e($edit_staff->address); ?>" minlength="3" maxlength="70" name="address">
                            </div>
                            <span style="color: red;"><?php echo e($errors->first('address')); ?></span>

                            <button type="submit" class="btn btn-info" name="update_Staff">Submit</button>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- het form thong tin chinh sua -->
            </div>
        </section>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/Admin/staff/edit.blade.php ENDPATH**/ ?>