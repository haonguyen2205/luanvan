
<?php $__env->startSection('admin_content'); ?>

<div class="table-agile-info">
    <div class="panel panel-default">
      <div class="panel-heading">
        Danh sách nhân viên
      </div>
      <div>
          <ul class="nav nav-tabs">
              <li><a href="<?php echo e(URL::to('/list_staff')); ?>" > <span class="glyphicon glyphicon-user"></span> DS Nhân Viên </a></li>
              <li><a href="<?php echo e(URL::to('/list_staff/list-staff-block')); ?>"><span class="glyphicon glyphicon-user"></span> DS NV khóa</a></li>
          </ul>
        </div>
      <div class="row w3-res-tb">
        <div class="col-sm-4 m-b-xs">
              <a href="<?php echo e(URL::to('/page_add_staff')); ?>" class="btn btn-info"><i class="fa fa-plus"></i> thêm nhân viên</a> 
        </div>

        <div class="col-sm-4">

        </div>

        <!-- thanh search -->
        <div class="col-sm-4">
          <div class="input-group">
            <form action="<?php echo e(URL::to('/list_staff')); ?>"  >
            <?php echo e(csrf_field()); ?>  
            <span>Search</span>
                <input type="text" class="input-sm fa fa-search" name="search_staff" placeholder="Search">
                <!-- <span class="input-group-btn">             
                  <button class="btn btn-sm btn-default" type="button">Go!</button>
                </span> -->
            </form>
          </div>
        </div>
        <!-- end search -->
      </div>

      <!-- show data in table -->
      <div class="table-responsive">
        <table class="table table-striped b-t b-light">
          <thead>
            <tr>
              <th style="width:20px;"></th>
              <th>tên nhân viên</th>
              <Th>avatar</th>
              <Th>chức vụ</th>
              <th>email</th>
              <th>số điện thoại</th>
              <th>địa chỉ nhà</th>
              <th>CRUD</th>
              <th style="width:30px;"></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $liststaff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><label class="i-checks m-b-none"><i></i></label></td>
                <td> <?php echo e($staff->name); ?> </td>
                <td>
                    <div class="single-room-pic">
                      <img src="public/upload/staff/<?php echo e($staff->users_image); ?>" height="100"; width="100";>
                    </div>
                </td>
                <td> <?php echo e($staff->postion_name); ?> </td>
                <td> <?php echo e($staff->email); ?> </td>
                <td> <?php echo e($staff->phone); ?> </td>
                <td> <?php echo e($staff->address); ?> </td>
                <td>
                  <a href="<?php echo e(URL::to('/edit_staff/'.$staff->users_id)); ?>" class="active" style="font-size: 21px;" ui-toggle-class="">
                    <i class="fa fa-pencil-square-o text-success text-active"></i>
                  </a>
                  <a href="<?php echo e(URL::to('/delete-staff/'.$staff->users_id)); ?>" onClick="return confirm('Bạn thực sự muốn xóa ?')"class="active" style="font-size: 21px;"  ui-toggle-class="">
                    <i class="fa fa-times text-danger text"></i>
                  </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <!-- end show data -->


      <footer class="panel-footer">
        <div class="row">
          <div class="col-sm-7 text-right text-center-xs">
          <!-- link chuyển trang                 -->
            <?php echo e($liststaff->links()); ?> 
          </div>
        </div>
      </footer>
    </div>
          </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/Admin/staff/list.blade.php ENDPATH**/ ?>