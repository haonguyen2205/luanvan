
<?php $__env->startSection('admin_content'); ?>
<div class="table-agile-info">
    <div class="panel panel-default">
        <div class="panel-heading">
            Danh sách tin tức
        </div>
        <div class="row w3-res-tb">
            <div class="col-sm-3"></div>
            <div class="col-sm-3">
                <div class="input-group">
                    <form action="<?php echo e(URL::to('new-search')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <div class="btn">
                            <input type="text" class="input-sm fa fa-search" name="search" placeholder="Nhập tên khách hàng">
                            <button type="submit"  class="btn btn-primary" value="Tìm kiếm"><i class="fas fa-search"></i> TÌM KIẾM</button>
                            <a href="<?php echo e(URL::to('/add-new')); ?>" class="btn btn-primary">Thêm tin tức</a>
                        </div>
                    </form>
                </div>
            </div>  
            <div class="col-sm-3"></div>
            <div class="col-sm-3"></div>
        </div>


        <div class="table-responsive">
            <table class="table table-striped b-t b-light">
                <thead>
                    <tr>
                        <th style="width:10px;"></th>
                        <th style="width:10px;">Id</th>
                        <th style="width:100px; text-align: center">Image</th>
                        <th style="width:150px;">Mô tả</th>
                        <th style="width: 372px;">Nội dung</th>
                        <th style="width:200px;">Ngày đăng</th>
                        <th style="width:150px;"></th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $listNew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="width:10px;"><label class="i-checks m-b-none"><i></i></label></td>
                        <td style="width:10px;"><?php echo e($value->new_id); ?></td>
                        <td style="width:100px;height:100px ;text-align: center">
                            <?php if($value->new_image != null): ?>
                            <div class="single-room-pic">
                                <img src="images/<?php echo e($value->new_image); ?>" height="100"; width="100";>
                            </div>
                            <?php endif; ?>
                        </td>
                        <td style="width:150px;"><?php echo e($value->new_name); ?></td>
                        <td style="width: 372px;">
                            <?php
                                echo $value->new_content;
                            ?>
                        </td>
                        <td style="width:200px;">  <?php
                                            
                                            $date= date_create($value->date_post);
                                             echo date_format($date,"Y/m/d");
                                             
                                             ?></td>
                        <td style="width:150px;">
                            <a href="<?php echo e(URL::to('/edit-new',$value->new_id)); ?>" class="active" style="font-size: 21px;" ui-toggle-class="">
                                <i class="fa fa-pencil-square-o text-success text-active"></i>
                            </a>
                            <a href="<?php echo e(URL::to('/delete-new',$value->new_id)); ?>" onClick="return confirm('Are you confirm to delete ?')"class="active" style="font-size: 21px;"  ui-toggle-class="">
                                <i class="fa fa-times text-danger text"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
        </div>
    </div>
</div>
<script>

    <?php if(Session::has('addtintuc')): ?>
        alert("Đã thêm thành công");
        @Session::forget('addtintuc');
    <?php endif; ?>


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/Admin/news/list-new.blade.php ENDPATH**/ ?>