
<?php $__env->startSection('content'); ?>
<!-- Hero Section Begin -->
<section class="hero-section set-bg" data-setbg="<?php echo e(URL::asset('public/frontend/img/services-bg.jpg')); ?>">
        <div class="hero-text">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h1>News</h1>
                    </div>
                </div>
                <div class="page-nav">
                    <a href="<?php echo e(URL::to('/rooms')); ?>" class="left-nav"><i class="lnr lnr-arrow-left"></i> Rooms</a>
                    <a href="<?php echo e(URL::to('/contact')); ?>" class="right-nav">Contact <i class="lnr lnr-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->

    <!-- Blog Section Begin -->
    <section class="blog-section spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 order-2 order-lg-1">
                    <div class="side-bar">
                        <div class="recent-post">
                            <h4><b>Danh muc</b></h4>
                            <div class="single-recent-post">
                                <div class="recent-text">
                                <?php $__currentLoopData = $showPageCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(URL::to('news',$value->cat_id)); ?>"><h5><u><?php echo e($value->cat_name); ?></u></h4></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <div class="tags-item">
                            <h4>Tags</h4>
                            <div class="tag-links">
                                <a href="/">hotel</a>
                                <a href="https://w3layouts.com/">theme</a>
                                <a href="/rooms">room</a>
                                <a href="https://color.adobe.com/create/color-wheel">Color</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8 order-1 order-lg-2">
                    <?php $__currentLoopData = $showPageNew; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $showNews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="blog-post">
                        <div class="single-blog-post">
                            <div class="blog-pic">
                                <img src="<?php echo e(URL::to('images/'.$showNews->new_image)); ?>" alt="">
                            </div>
                            <div class="blog-text">
                                <h4><?php echo e($showNews->new_name); ?></h4>
                                <div class="blog-widget">
                                    <div class="blog-info">
                                        <i class="lnr lnr-user"></i>
                                        <span>Admin</span>
                                    </div>
                                    <div class="blog-info">
                                        <img src="<?php echo e(URL::asset('public/frontend/img/clock.png')); ?>" alt="">
                                        <span>
                                            <?php
                                            
                                       $date= date_create($showNews->date_post);
                                        echo date_format($date,"Y/m/d");
                                        
                                        ?></span>
                                    </div>
                                </div>
                                <?php
                                    echo $showNews->new_content;
                                ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </div>
    </section>
    <!-- Blog Section End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/layout/news.blade.php ENDPATH**/ ?>