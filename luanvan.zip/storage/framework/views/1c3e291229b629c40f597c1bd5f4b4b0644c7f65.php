

<?php
use Illuminate\Support\Facades\Session;
?>
<?php $__env->startSection('admin_content'); ?>
<div class="table-agile-info">
    
    <div class="panel panel-default">
      <div class="panel-heading">
        <Div>Danh sách phòng</Div>
    </div>
    <ul class="nav nav-tabs">
              <li><a href="<?php echo e(URL::to('/list-room')); ?>" > <span class="glyphicon glyphicon-bed"></span> DS phòng </a></li>
              <li><a href="<?php echo e(URL::to('/list-room-block')); ?>" ><span class="glyphicon glyphicon-bed"></span> DS phòng KO HĐ</a></li>
              <li><a href="<?php echo e(URL::to('/list-empty-room')); ?>" ><span class="glyphicon glyphicon-bed"></span> tìm phòng rỗng</a></li>
              <li><a href="<?php echo e(URL::to('/list-of-occupied')); ?>" ><span class="glyphicon glyphicon-bed"></span> DS phòng có ngưởi ở</a></li>
          </ul>
      <div class="row w3-res-tb">
        <div class="col-sm-5 m-b-xs">
          <?php if(session::get('postion')==4): ?>
           <a href="<?php echo e(URL::to('/add-room')); ?>" class="btn btn-info "><i class="fa fa-plus"></i> Thêm phòng</a>    
          <?php endif; ?>
             
        </div>
        <div class="col-sm-3">
          
        </div>
          <div class="col-sm-4">
            <div class="input-group">
              <form action="<?php echo e(URL::to('/list-room')); ?>" method="get">
              <?php echo e(csrf_field()); ?> Search :
                <input type="text" class="input-sm fa fa-search" name="keyword" placeholder="Search">
                <span class="input-group-btn">
                  
                </span>
              </form>
            </div>
          </div>
      </div>
      <div class="table-responsive">
        <table class="table table-striped b-t b-light">
          <thead>
            <tr>
              <th style="width:20px;"></th>
              <th width="10%">Tên phòng</th>
              <th width="25%" >Hình ảnh</th>
              <th width="15%">Loại phòng</th>

              <th>Giá</th>
              <th>Tình trạng</th>
              <th width="5%">Action</th>
              <th style="width:30px;"></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $listRoom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <tr>
                <td><label class="i-checks m-b-none"><i></i></label></td>
                <td> <?php echo e($value->room_name); ?> </td>
                <td>
                    <div class="single-room-pic">
                      <img src="public/upload/rooms/<?php echo e($value->image); ?>" height="150"; width="250";>
                    </div>
                </td>
                <td> Loại : <?php echo e($value->type_name); ?> </td>

                <td> <?php echo e(number_format($value->room_price).' đ/ngày'); ?> </td>
                 <td><span class="text-ellipsis">
                  <?php
                    if($value->room_status==0) {
                  ?>
                  <a href="<?php echo e(URL::to('/inactive-room/'.$value->room_id)); ?>" style="color:red">Không hoạt động</a>
                  <?php
                  }
                  else {
                  ?>
                    <a href="<?php echo e(URL::to('/active-room/'.$value->room_id)); ?>" style="color:green">Hoạt động</a>
                  <?php
                    }
                  ?>
                  </span>
                </td> 
                <td >
                  <a href="<?php echo e(URL::to('/edit-room/'.$value->room_id)); ?>" class="active" style="font-size: 21px;" ui-toggle-class="">
                    <i class="fa fa-pencil-square-o text-success text-active"></i>
                  </a>
                  <!-- <a href="<?php echo e(URL::to('/delete-room/'.$value->room_id)); ?>" onClick="return confirm('Are you confirm to delete ?')"class="active" style="font-size: 21px;"  ui-toggle-class="">
                    <i class="fa fa-times text-danger text"></i>
                  </a> -->
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      <footer class="panel-footer">
        <div class="row">
          <div class="col-sm-7 text-right text-center-xs"> 
          <?php echo e($listRoom->links()); ?>               
          </div>
        </div>
      </footer>
    </div>
          </div>


  <?php if(Session::has('mes_createRoom')): ?>
    <script type="text/javascript" >
      swal("Congratulation!","<?php echo e(Session::Get('mes_createRoom')); ?>","success",{
        button:"OK",
      });
      <?php
      session::put('mes_createRoom',null);
    ?>
    </script> 
    
  <?php endif; ?>   
      
  <?php if(Session::has('mes_updateRoom')): ?>
    <script type="text/javascript" >
      swal("Congratulation!","<?php echo e(Session::Get('mes_updateRoom')); ?>","success",{
        button:"OK",
      });
      <?php
      session::put('mes_updateRoom',null);
    ?>
    </script> 
  <?php endif; ?>

  <?php if(Session::has('mes_act_room')): ?>
    <script type="text/javascript" >
      swal("Congratulation!","<?php echo e(Session::Get('mes_act_room')); ?>","error",{
        button:"OK",
      });
      <?php
      session::put('mes_act_room',null);
    ?>
    </script> 
  <?php endif; ?>

  <?php if(Session::has('mes_update_fail')): ?>
    <script type="text/javascript" >
      swal("Thông báo!","<?php echo e(Session::Get('mes_update_fail')); ?>","error",{
        button:"OK",
      });
      <?php
      session::put('mes_update_fail',null);
    ?>
    </script> 
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/Admin/room/list.blade.php ENDPATH**/ ?>