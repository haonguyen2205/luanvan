
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Cập nhật phòng
            </header>
            <div class="panel-body">
                <?php
                    $msg = Session::get('msg');
                    if($msg) {
                        echo "<b style='color:red; padding-left:500px;'>".$msg."</b>";
                        Session::put('msg',null);
                    }
                ?>
                <div class="position-center">
                    <?php $__currentLoopData = $editRoom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$valueRoom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form role="form" action="<?php echo e(URL::to('/update-room/'.$valueRoom->room_id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Tên phòng</label>
                                <input type="text" class="form-control" id="exampleInputEmail1" name="name"
                                value="<?php echo e($valueRoom->room_name); ?>">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Image</label>
                                <input type="file" class="form-control" id="exampleInputEmail1"  name="image">
                                
                                <img src="<?php echo e(URL::to('/public/upload/rooms/'.$valueRoom->image)); ?>" height="100" weight="100"/>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputFile">Loại</label>
                                <select name="type" class="form-control m-bot15">
                                    <option value="<?php echo e($valueRoom->type_id); ?>"><?php echo e($valueRoom->type_name); ?></option>
                                    <?php $__currentLoopData = $editType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$valueType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($valueType->type_id); ?>"><?php echo e($valueType->type_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                </select>
                            </div> 
                            <div class="form-group">
                                <label for="exampleInputPassword1">Mô tả</label>
                                <textarea style="resize:none" rows="8" class="form-control" name="description" id="exampleInputPassword1">
                                    <?php echo e($valueRoom->room_description); ?>

                                </textarea>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Giá</label>
                                <input type="number" class="form-control" id="exampleInputEmail1" name="price"
                                value="<?php echo e($valueRoom->room_price); ?>">
                            </div>
                            <!-- <div class="form-group">
                                <label for="exampleInputFile">Tình trạng</label>
                                <select name="status" class="form-control m-bot15">
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div> -->
                            <button type="submit" class="btn btn-info" name="addRoom">Submit</button>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>
    </div>
</div>
<?php if(Session::has('mes_update_fail')): ?>
    <script type="text/javascript" >
      swal("Congratulation!","<?php echo e(Session::Get('mes_update_fail')); ?>","error",{
        button:"OK",
      });
      <?php
      session::put('mes_update_fail',null);
    ?>
    </script> 
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/admin/room/edit.blade.php ENDPATH**/ ?>