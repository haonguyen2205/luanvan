<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2>{{$body}}</h2>
    <h2>tài khoản của bạn được tạo với tên: {{$name}}</h2>
    
    <h2>mật khẩu của tài khoản:{{$password}}</h2>

    <div><a href="{{URL('/')}}">active</a></div>

    <h3>nếu không phải chủ mail xin đừng ấn linh tinh</h3>
</body>
</html>