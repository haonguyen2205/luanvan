

<?php $__env->startSection('admin_content'); ?>
<?php
// $so = $endt->day - $start->day;
// // $songay = $so/86400;
// echo $so;
?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Đặt phòng theo yêu cầu khách hàng
            </header>
           
            <div class="panel-body">

                <div class="position-center">
                    <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    
                    <?php   
                    
                        $so = strtotime($endt) - strtotime($start);
                        $songay = $so/86400;

                        
                        $tiencoc = ($tongtien *40)/100;
                    ?>

                        <form role="form" action="<?php echo e(URL::to('/add-order-by-admin/'.$row->room_id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                            
                            <div class="form-group">
                            <label for="exampleInputEmail1">người đặt phòng</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" name="name" minlength="6" maxlength="50" required>
                            </div>
                            <div class="row">
                                <div class=" col-md-3">
                                    <label for="exampleInputEmail2">ngày nhận phòng</label>
                                    <input type="date" class="form-control"name="start" value="<?php echo e($start); ?>" readonly  >
                                </div>
                                <div class=" col-md-3">
                                <label for="exampleInputEmail2">ngày trả phòng</label>
                                    <input type="date" class="form-control" name="end" value="<?php echo e($endt); ?>" readonly  >
                                </div>  
                                </br>
                                <div class=" col-md-3">
                                    <label type="date" name="end_time" value="<?php echo e($endt); ?>" readonly="readonly"> số ngày cuối tuần : <?php echo e($cuoituan); ?> </label>
                                </div> 
                                </br>  
                                </br>  
                            </div>
                            <div class="row my-2">
                                <div class="col-md-3">
                                    <label for="exampleInputEmail1">Adults</label>
                                    <input type="number" class="form-control" value="1" min="1" max="2"  name="adults" required>
                                </div> 
                                <div class="col-md-1"></div>
                                <div class="col-md-3">
                                    <label for="exampleInputEmail1">Kids</label>
                                    <input type="number" class="form-control" value="0"  min="0" max="2" name="children" required>
                                </div> 
                            </div>
                            </br>
                            <div class="row my-3">
                                <div class="col-md-3 my-2">
                                    <label for="exampleInputEmail1">CMND/CCCD</label>
                                    <input type="text" class="form-control" minlength="10" maxlength="12"  name="CMND" required>
                                </div> 
                                <div class="col-md-1"></div>
                                <div class="col-md-4">
                                    <label for="exampleInputEmail1">giá phòng</label>
                                    <input type="number" class="form-control"  value="<?php echo e(($row->room_price)); ?>" disabled min="200000"  name="room_price" readonly required>
                                </div> 
                            </div>
                            </br>
                            <div class="row my-3">
                                <div class="col-md-4 my-2">
                                    <label for="exampleInputEmail1">Tổng tiền : <?php echo e(number_format($tongtien)); ?> đồng</label>
                                    <input type="hidden" class="form-control" value="<?php echo e($tongtien); ?>"   name="total"  required readonly>
                                </div> 
                                <div class="col-md-4">
                                    <label for="exampleInputEmail1">Tiền cọc(40%): <?php echo e(number_format($tiencoc)); ?> đồng</label>
                                    <input type="hidden" class="form-control" value="<?php echo e($tiencoc); ?>"   name="deposit"  required readonly>
                                </div> 
                            </div>
                            </br>
                            <div class="form-group mt-5">
                                <input type="submit" class="btn btn-primary mt-5 m" margin-top="8px" value="đặt phòng">
                            </div>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </section>

    </div>
</div>
            <div class="my-5">
                <div class="container">
                    <div class="row">
                        <div class="owl-carousel owl-theme ">
                            <?php $__currentLoopData = $img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imgroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item">
                                    <div> </div>
                                    <div class="col mt-5 mb-5">
                                        <div class="cart">
                                            
                                            <img src="<?php echo e(asset('public/upload/rooms/'.$imgroom->room_image)); ?>" width="350" height="200">
                                            
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>  

            <Script>
    $(document).ready(function () {
        (function ($) {
            $('.owl-carousel').owlCarousel({
                margin: 10,
                // slideSpeed : 800,
                // autoPlay: 2000,
                items : 3,
                autoplay:true,
                autoplayTimeout:2000,
                loop: true,
                stopOnHover : true,
                itemsDesktop : [1199,1],
                itemsDesktopSmall : [979,1],
                itemsTablet :   [768,1],
            });
        })(jQuery);
    });
</Script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/admin/order/add_order.blade.php ENDPATH**/ ?>