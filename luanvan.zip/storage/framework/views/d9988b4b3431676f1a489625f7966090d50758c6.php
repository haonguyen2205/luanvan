
<?php $__env->startSection('admin_content'); ?>
<div class="table-agile-info">
    <div class="panel panel-default">
      <div class="panel-heading">
        DANH SÁCH ĐƠN HÀNG ĐÃ XOÁ
      </div>
      <div class="row w3-res-tb">
        <div class="col-sm-4">
          
        </div>
        
      </div>
      <div class="table-responsive">
        <table class="table table-striped b-t b-light">
          <thead>
            <tr>
              <th style="width:20px;">ID</th>
              <th>Tên người đặt</th>
              <th>CMND</th>
              <th> Phòng </th>   
              <th>Tổng tiền</th>
              <th>Ngày nhận</th>
              <th>Ngày trả</th>
              <th>Tình trạng</th>
              <th>Tiền cọc</th>
             
            </tr>
          </thead>
          <tbody>
            

                <?php $__currentLoopData = $ds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><label class="i-checks m-b-none"><i><?php echo e($key['id']); ?></i></label></td>
                <td> <?php echo e($key['name']); ?> </td>
                <td> <?php echo e($key['cmnd']); ?> </td>
                <td> <?php echo e($key['phong']); ?> </td>
               
                <td><span class="text-ellipsis"><?php echo e(number_format($key['tongtien'],0)); ?>VND</span></td>
                <td><span class="text-ellipsis"><?php echo e($key['ngaynhan']); ?></span></td>
                <td><span class="text-ellipsis"><?php echo e($key['ngaytra']); ?></span></td>
                <td><span class="text-ellipsis">
                    Đã xoá
                </span></td>
                <td><?php echo e(number_format($key['deposit'],0)); ?> VND</td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          </tbody>
        </table>
      </div>
    </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/Admin/order/dsxoa.blade.php ENDPATH**/ ?>