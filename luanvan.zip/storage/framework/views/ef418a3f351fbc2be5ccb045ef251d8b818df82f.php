
<?php $__env->startSection('admin_content'); ?>



<div class="table-agile-info">
    
    <div class="panel panel-default">
      <div class="panel-heading">
        Danh sách tiện ích 
      </div>
      
      <div class="row w3-res-tb">
        <div class="col-sm-4 m-b-xs">
              <A href="<?php echo e(URL::to('/add-uti')); ?>" class="btn btn-info"><i class="fa fa-plus"></i> thêm tiện ích</A>                
        </div>

        <div class="col-sm-3">
        </div>

        <!-- thanh search -->
        <div class="col-sm-4">
          <div class="input-group">
            <form action="<?php echo e(URL::to('/list-uti')); ?>"  >
            <?php echo e(csrf_field()); ?>  
            <Span>Search</Span>
                <input type="text" class="input-sm fa fa-search" name="search_uti" placeholder="Search">
                <!-- <span class="input-group-btn">             
                  <button class="btn btn-sm btn-default" name="btn_uti" type="button">Search!</button>
                </span> -->
            </form>
          </div>  
        </div>
        <!-- end search -->
      </div>
        
      <!-- show du luieu -->
      <div class="table-reponsive">
        <table class="table table-striped b-t b-light">
          <thead>
            <tr>
              <th style="width:10px;"></th> 
              <th width="30%" >Mã</th>
              <Th>Tên tiện ích</th>
              <Th>giá tiện ích</th>
              <Th>ảnh</th>
              <th width="20%">Action</th>
              <th style="width:10px;"></th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $list_uti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $uti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><label class="i-checks m-b-none"><i></i></label></td>
                <td> <?php echo e($uti->utility_id); ?> </td>
                <td> <?php echo e($uti->utility_name); ?> </td>
                <td> <?php echo e($uti->utility_price); ?> </td>
                <td> <img src="public/upload/utility/<?php echo e($uti->utility_image); ?>" width="70px" height="50px"> </td>
                <td>
                  <a href="<?php echo e(URL::to('/edit-uti/'.$uti->utility_id)); ?>" class="active" style="font-size: 21px;" ui-toggle-class="">
                    <i class="fa fa-pencil-square-o text-success text-active"></i>
                  </a>
                  <a href="<?php echo e(URL::to('/delete-uti/'.$uti->utility_id)); ?>" onClick="return confirm('Bạn thực sự muốn xóa ?')"class="active" style="font-size: 21px;"  ui-toggle-class="">
                    <i class="fa fa-times text-danger text"></i>
                  </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>  
</div>

<?php if(Session::has('mes_create_uti')): ?>
  <script type="text/javascript" >
    swal("Congratulation!","<?php echo e(Session::Get('mes_create_uti')); ?>","success",{
      button:"OK",
    });
  </script> 
  <?php
    session::put('mes_create_uti',null);
  ?>
<?php endif; ?>

<?php if(Session::has('mes_update_uti')): ?>
  <script type="text/javascript" >
    swal("thành công!","<?php echo e(Session::Get('mes_update_uti')); ?>","success",{
      button:"OK",
    });
  </script> 
  <?php
    session::put('mes_update_uti',null);
  ?>
<?php endif; ?>

<?php if(Session::has('mes_delete_uti')): ?>
  <script type="text/javascript" >
    swal("thông báo!","<?php echo e(Session::Get('mes_delete_uti')); ?>","warning",{
      button:"OK",
    });
  </script> 
  <?php
    session::put('mes_delete_uti',null);
  ?>
<?php endif; ?>

<?php if(Session::has('mes_fails')): ?>
  <script type="text/javascript" >
    swal("lỗi!","<?php echo e(Session::Get('mes_update')); ?>","error",{
      button:"OK",
    });
  </script> 
  <?php
    session::put('mes_fails',null);
  ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/Admin/utility/list.blade.php ENDPATH**/ ?>