
<?php $__env->startSection('admin_content'); ?>
<div class="table-agile-info">
    <div class="panel panel-default">
    <div class="panel-heading"> DANH SÁCH ĐƠN HÀNG </div>

    <!-- search -->
    <div class="row w3-res-tb">
        <div class="col-sm-3">
        </div>
            <div class="col-sm-3">
                <div class="input-group">
                    <form action="<?php echo e(URL::to('timkiem')); ?>" method="get">
                        <?php echo csrf_field(); ?>
                        <div class="btn">
                            <input type="text" class="input-sm form-control" name="search" placeholder="Nhập tên khách hàng">
                            <button type="submit"  class="btn btn-primary" value="Tìm kiếm"><i class="fas fa-search"></i> TÌM KIẾM</button>
                            <a href="<?php echo e(URL::to('/admin/manage-order')); ?>" class="btn btn-primary">Trở về</a>
                        </div>
                    </form>
                </div>
            </div>
        <div class="col-sm-3"></div>
        <div class="col-sm-3"></div>
    </div>

    <!-- Bảng danh sách -->
    <div class="table-responsive">
        <table class="table table-striped b-t b-light">
        <thead>
            <tr>
            <th style="width:10px;">ID</th>
            <th>Tên người đặt</th>
            <th>Tổng tiền</th>
            <th>Ngày nhận</th>
            <th>Ngày trả</th>
            <th>Tình trạng</th>
            <th>Tiền cọc</th>
            <th style="width:30px;">Action</th>
            </tr>
        </thead>
        <tbody>


                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
            <td><label class="i-checks m-b-none"><i><?php echo e($key->order_id); ?></label></td>
                <td><label class="i-checks m-b-none"><i><?php echo e($key->username); ?></label></td>

                <td><span class="text-ellipsis"><?php echo e(number_format($key->total,0)); ?>VND</span></td>
                <td><span class="text-ellipsis"><?php echo e($key->dayat); ?></span></td>
                <td><span class="text-ellipsis"><?php echo e($key->dayout); ?></span></td>
                <td><span class="text-ellipsis">




                <?php if($key->status==1): ?>
                        <a style="color:red" href="<?php echo e(URL::to('uptt',$key->order_id)); ?>">Chờ xác nhận</a>
                        <?php endif; ?>
                            <?php if($key->status==2): ?>
                            <a style="color:black" href="<?php echo e(URL::to('uptt',$key->order_id)); ?>">Đã xác nhận</a>;
                        <?php endif; ?>
                            <?php if($key->status==3): ?>
                            <a style="color:green" href="<?php echo e(URL::to('uptt',$key->order_id)); ?>">Đã lấy phòng</a>;
                        <?php endif; ?>
                            <?php if($key->status==4): ?>
                            <p style="color:blue">Hoàn thành</p>



                    <?php endif; ?>
                </span></td>
                <td><?php echo e(number_format($key->deposit,0)); ?> VND</td>
                <td>
                <a href="<?php echo e(URL::to('/admin/chitietorder',$key->order_id)); ?>" class="active" style="font-size: 21px;"  ui-toggle-class="">
                Chi tiết
                </a>
                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
        </table>
    </div>
    </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/Admin/order/search.blade.php ENDPATH**/ ?>