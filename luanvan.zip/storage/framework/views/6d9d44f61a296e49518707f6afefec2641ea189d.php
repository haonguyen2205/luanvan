


<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Thêm phòng
            </header>
           
            <div class="panel-body">
                <div class="position-center">
                    <form role="form" action="<?php echo e(URL::to('/add-room-action')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Tên phòng</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" name="name" required>
                        </div>
                        <span style="color: red;"><?php echo e($errors->first('name')); ?></span>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Image</label>
                            <input type="file" class="form-control" id="exampleInputEmail1" name="image" accept="image/*"   >   
                        </div>
                        <span style="color: red;"><?php echo e($errors->first('image')); ?></span>

                        <div class="form-group">
                            <label for="exampleInputFile">Loại phong</label>
                            <select name="type" class="form-control m-bot15">
                                <?php $__currentLoopData = $typeName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->type_id); ?>"><?php echo e($value->type_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Mô tả</label>
                            <textarea style="resize:none" rows="8" class="form-control" name="description" id="exampleInputPassword1">
                            </textarea>
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Giá</label>
                            <input type="number" class="form-control" id="exampleInputEmail1" name="price" required> 
                        </div>
                        <span style="color: red;"><?php echo e($errors->first('price')); ?></span>

                        <div class="form-group">
                            <label for="exampleInputFile">Tình trạng</label>
                            <select name="status" class="form-control m-bot15">
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-info" name="addRoom">Xác nhận thêm </button>
                    </form>
                </div>

            </div>
        </section>

    </div>
</div>

    <?php if(Session::has('mes_create_fail')): ?>
        <script type="text/javascript" >
        swal("Ohh Fail!","<?php echo e(Session::Get('mes_create_fail')); ?>","error",{
            button:"OK",
        });
        </script> 
        <?php
        session::put('mes_create_fail',null);
        ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/Admin/room/add.blade.php ENDPATH**/ ?>