
<?php $__env->startSection('admin_content'); ?>
<div class="row">
    <div class="col-lg-12">
    <section class="panel">
            <header class="panel-heading">
                THÊM DANH MỤC
            </header>
            <div class="panel-body">
                <div class="position-center">
                    <form role="form" action="<?php echo e(URL::to('/add-cat-action')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                        <span style="color: red;"><?php echo e($errors->first('catName')); ?></span>
                        <div class="form-group">
                            <label for="exampleInputEmail1">Loại tin tức</label>
                            <input type="text" class="form-control" id="exampleInputEmail1" min="3" max="50" name="catName">
                        </div>

                        <button type="submit" class="btn btn-primary" name="addCat">Thêm danh mục</button>
                        <a href="<?php echo e(URL::to('/list-cat')); ?>" class="btn btn-primary">Trở về</a>
                    </form>
                </div>
            </div>
        </section>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/Admin/category/add-cat.blade.php ENDPATH**/ ?>