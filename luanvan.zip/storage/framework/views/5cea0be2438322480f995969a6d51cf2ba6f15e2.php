
<?php $__env->startSection('customer_content'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('profile_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\luanvan\resources\views/profile/layout.blade.php ENDPATH**/ ?>